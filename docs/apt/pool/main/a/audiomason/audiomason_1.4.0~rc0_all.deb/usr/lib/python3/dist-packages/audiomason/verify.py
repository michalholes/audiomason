from __future__ import annotations

from pathlib import Path

from mutagen.id3 import ID3
from mutagen.id3._util import ID3NoHeaderError

import audiomason.metadata_lookup as metadata_lookup
from audiomason.naming import normalize_name
from audiomason.paths import COVER_NAME
from audiomason.util import out

READ_ONLY_VERIFY = True


def verify_library(root: Path, cfg: dict[str, object] | None = None) -> None:
    """
    Verify audiobook library:
    - each book dir has cover.jpg
    - mp3 files have ID3 tags
    """
    authors: list[Path] = [p for p in sorted(root.iterdir()) if p.is_dir()]
    books: list[Path] = []
    for a in authors:
        books.extend([p for p in sorted(a.iterdir()) if p.is_dir()])
    out(f"[verify] scanning {len(books)} book(s) under {root}")

    # Name normalization report (read-only)
    for a in [p for p in sorted(root.iterdir()) if p.is_dir()]:
        na = normalize_name(a.name)
        if na != a.name:
            out(f"[name] author: '{a.name}' -> '{na}'")
        for b in [p for p in sorted(a.iterdir()) if p.is_dir()]:
            nb = normalize_name(b.name)
            if nb != b.name:
                out(f"[name]   book: '{b.name}' -> '{nb}'")

    # Metadata validation (read-only)
    if metadata_lookup.is_enabled(cfg) and root.exists():
        # Expect layout: root/Author/Book
        authors = [p for p in sorted(root.iterdir()) if p.is_dir()]
        out(f"[verify] metadata: authors={len(authors)}")
        for a in authors:
            ar = metadata_lookup.validate_author(a.name, cfg)
            out(
                f"[ol] {a.name}: {ar.status} hits={ar.hits}"
                + (f" top='{ar.top}'" if ar.top else "")
            )
            books = [p for p in sorted(a.iterdir()) if p.is_dir()]
            for b in books:
                br = metadata_lookup.validate_book(a.name, b.name, cfg)
                out(
                    f"[ol]   {b.name}: {br.status} hits={br.hits}"
                    + (f" top='{br.top}'" if br.top else "")
                )

    missing_cover = 0
    missing_tags = 0

    for book in books:
        cover = book / COVER_NAME
        if not cover.exists():
            out(f"[verify] missing cover: {book.name}")
            missing_cover += 1

        mp3s = sorted(book.glob("*.mp3"))
        for mp3 in mp3s:
            try:
                ID3(mp3)  # type: ignore[no-untyped-call]
            except ID3NoHeaderError:
                out(f"[verify] missing ID3 tags: {book.name}/{mp3.name}")
                missing_tags += 1

    out(
        f"[verify] done: "
        f"books={len(books)}, "
        f"missing_cover={missing_cover}, "
        f"missing_tags={missing_tags}"
    )
